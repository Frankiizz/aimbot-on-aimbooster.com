import cv2
import numpy as np

while True:
	img = cv2.imread('target.png', 1)

	hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
	low_orange = np.array([11, 59, 255])
	up_orange = np.array([12, 60, 255])

	mask = cv2.inRange(hsv, low_orange, up_orange)

	kernel = np.ones((5, 5), np.uint8)
	mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
	mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

	contours, hierarchy = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

	for contour in contours:
		x, y, w, h = cv2.boundingRect(contour)
		img = cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
		cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)

	cv2.imshow('img', img)
	cv2.imshow('mask', mask)
	cv2.waitKey(1)
