
# It is an aim bot for aimbooster.com


import time

import cv2
import keyboard
import win32con, win32api
import numpy as np
import mss


# move to x,y and click by win32api
def click(x, y):
	win32api.SetCursorPos((x, y))
	win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0)
	time.sleep(0.01)
	win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0)
	time.sleep(0.1)

	print('click', x, y)



# Set Monitor size(for grab)
monitor = {'top': 0, 'left': 0, 'width': 1000, 'height': 800}

# Grab the monitor
with mss.mss() as sct:
	# Press 'q' to shop
	while keyboard.is_pressed('q') == False:
		img_or = sct.grab((monitor))
		img = np.array(img_or)
		hsv_img = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

		# Set the target color in H,S,V formate.
		# The low and up are a range of detections.
		low_orange = np.array([11, 59, 255])
		up_orange = np.array([12, 60, 255])
		mask = cv2.inRange(hsv_img, low_orange, up_orange)
		# Get the mask, make another colors black and only remain color I want as white on mask
		kernel = np.ones((5, 5), np.uint8)
		mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
		mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
		# Find the contours of white object on mask
		contours, hierarchy = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
		# get x,y location and its width and height
		for contour in contours:
			x, y, w, h = cv2.boundingRect(contour)
			img = cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 1)
			cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 1)
			x_loc, y_loc = int(x + 0.5 * w), int(y + 0.5 * h)
			click(x_loc, y_loc)

		# Show mask and monitor(Optional)
		cv2.imshow('targehsv', mask)
		cv2.imshow('pic', img)
		cv2.waitKey(1)




